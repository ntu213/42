
def count_in_list(lst, elem):
    """Fait des trucs"""

    i = 0

    for el in lst:
        if el == elem:
            i += 1

    return (i)
